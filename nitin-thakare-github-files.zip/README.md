# Nitin Thakare | Career Guidance & Educational Counselling

Personal brand website (single static page, no build step).

## Files
- `index.html` : the whole website (edit SERVICES, POSTS, EXPLORER, WORK, CFG at the top of the script)
- `robots.txt`, `sitemap.xml` : replace `YOUR-DOMAIN.com` with the real domain
- `netlify.toml` : tells Netlify to publish the repo root

## Deploy on Netlify (recommended: enquiry form works)
Netlify > Add new project > Import from GitHub > select this repo > Deploy.
Then Forms > form notifications > add email notification.

## GitHub Pages
The site loads, but the Netlify form will not work there. Set a Formspree URL in `CFG.formspree` inside `index.html`.
