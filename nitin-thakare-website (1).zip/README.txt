NITIN THAKARE WEBSITE: DEPLOY GUIDE (Hinglish)

Is folder mein: index.html (poori website), robots.txt, sitemap.xml.

STEP 1: Netlify par daalna (free)
1. netlify.com par account banaiye.
2. "Add new site" > "Deploy manually" par ye poora folder drag-drop kijiye.
3. Site live ho jayegi. Site settings se naam/domain badal sakte hain.

STEP 2: Enquiry ka email alert
1. Netlify > Forms > "enquiry" form dikhega (pehla submit hone ke baad).
2. Site configuration > Forms > Form notifications > "Add notification" > Email notification
   > ratanrthakare@gmail.com. Ab har enquiry aapke email par aayegi.
(Free plan mein mahine ki limit hoti hai, Netlify par check kijiye.)

Alternative: formspree.io par form banaiye, uska URL index.html mein CFG ke formspree:"" mein daaliye.

STEP 3: Baaki
- index.html mein YOUR-DOMAIN.com ko apni asli domain se badaliye (canonical, robots.txt, sitemap.xml).
- Google Analytics ID CFG mein ga:"" mein daaliye.
- Google Search Console mein site add karke sitemap.xml submit kijiye.
- Articles/services badalne ke liye index.html ke upar SERVICES, POSTS, EXPLORER list edit kijiye.
